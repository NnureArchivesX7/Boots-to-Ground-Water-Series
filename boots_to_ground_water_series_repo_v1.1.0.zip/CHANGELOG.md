## 1.1.0
- Added PNG fallbacks and placeholder note
