// Placeholder: future logic (theme toggles, per-site rules)
