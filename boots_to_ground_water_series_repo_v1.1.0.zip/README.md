# 🌊 Boots to Ground — Water Series (Starter Pack) — v1.1.0

**NnūrēTech / NnureArchivesX7**  
African coastal–inspired custom cursors. This version adds **PNG fallbacks** and uses **placeholder art** for rapid start-up. Replace the assets in `/assets` anytime with your final designs (keep the same filenames).

## Features
- Wooden Paddle pointer + Rope Hover cursor
- SVG with PNG fallbacks for compatibility
- Edge/Chromium Manifest V3

## Install (Edge)
1. `edge://extensions` → enable Developer mode  
2. Load unpacked → select this folder  
3. To publish: zip folder and upload to Partner Center

## Replace placeholders
Swap these files with your final art (keep filenames):
- `assets/pointer_paddle.svg` and `.png`
- `assets/pointer_rope_hover.svg` and `.png`

## License
CC BY-NC 4.0
