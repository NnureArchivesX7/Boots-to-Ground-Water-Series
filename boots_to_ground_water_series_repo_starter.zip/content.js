// Boots to Ground — content script placeholder
