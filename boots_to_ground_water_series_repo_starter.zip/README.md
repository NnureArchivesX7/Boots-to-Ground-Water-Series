# 🌊 Boots to Ground — Water Series (Starter Pack)

**Developed by NnūrēTech (NnureArchivesX7)**  
African coastal–inspired custom cursors, born from ancestral craftsmanship and digital artistry.

## ✨ Features
- Wooden Paddle pointer (direction, craft)  
- Rope Hover cursor (unity, connection)  
- SVG-based cursors, Edge/Chromium-ready (MV3)

## 🧩 Install as Edge Extension
1. Edge → `edge://extensions` → enable Developer mode  
2. Load unpacked → select this folder  
3. To publish: zip the folder and upload in Microsoft Partner Center

## 💻 Use in Web Pages
See `/examples/index.html` for a simple demo.

## 📩 Contact
nnuretech@gmail.com

## ⚖️ License
CC BY-NC 4.0
